# Minecraft Bot — GitHub Actions APK

## Cách dùng
1. Tạo/đổi sang repository GitHub public.
2. Upload toàn bộ các file/thư mục trong bộ này lên repo.
3. Vào `Actions`.
4. Chọn `Build Minecraft Bot APK`.
5. Bấm `Run workflow`.
6. Khi chạy xong màu xanh, mở run đó.
7. Kéo xuống `Artifacts` → `MinecraftBot-APK`.
8. Tải file `MinecraftBot-debug.apk` về điện thoại và cài.

GitHub Actions sẽ tự tạo project Android từ HTML bằng Cordova rồi build APK.

Không cần AndroidIDE và không cần app HTML-to-APK trả phí.

Lưu ý: APK hiện là HTML UI/prototype. Phần Connect/Farm chưa phải Minecraft protocol thật.
