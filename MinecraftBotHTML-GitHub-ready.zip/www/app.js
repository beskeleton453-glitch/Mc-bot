const $=id=>document.getElementById(id);
let mode="Java", connected=false, farming=false, startedAt=null, timer=null;

function log(msg){
  const el=$("console"), t=new Date().toLocaleTimeString();
  el.textContent += `[${t}] ${msg}\n`;
  el.scrollTop=el.scrollHeight;
}
function chat(type,msg){
  const d=document.createElement("div");
  d.className=type;
  d.textContent=msg;
  $("chatLog").appendChild(d);
  $("chatLog").scrollTop=$("chatLog").scrollHeight;
}
function save(){
  localStorage.setItem("mcBotConfig",JSON.stringify({
    mode,ip:$("serverIp").value,port:$("serverPort").value,user:$("username").value,
    auto:$("autoReconnect").checked,anti:$("antiAfk").checked
  }));
}
function load(){
  try{
    const c=JSON.parse(localStorage.getItem("mcBotConfig")||"{}");
    if(c.ip)$("serverIp").value=c.ip;
    if(c.port)$("serverPort").value=c.port;
    if(c.user)$("username").value=c.user;
    if(c.auto!=null)$("autoReconnect").checked=c.auto;
    if(c.anti!=null)$("antiAfk").checked=c.anti;
    if(c.mode){mode=c.mode;setMode(mode)}
  }catch(e){}
}
function setMode(m){
  mode=m;
  $("javaBtn").classList.toggle("active",m==="Java");
  $("bedrockBtn").classList.toggle("active",m==="Bedrock");
  $("modeText").textContent=m;
  $("serverPort").value=m==="Java"?"25565":"19132";
  log(`Protocol selected: ${m}`);
  save();
}
$("javaBtn").onclick=()=>setMode("Java");
$("bedrockBtn").onclick=()=>setMode("Bedrock");

function updateStatus(on){
  connected=on;
  $("statusPill").className="status "+(on?"online":"offline");
  $("statusPill").innerHTML=`<span></span> ${on?"ONLINE":"OFFLINE"}`;
  $("botState").textContent=on?"Connected":"Offline";
  $("connectBtn").disabled=on;
  $("disconnectBtn").disabled=!on;
  $("serverText").textContent=on?`${$("serverIp").value}:${$("serverPort").value}`:"—";
}
$("connectBtn").onclick=()=>{
  const ip=$("serverIp").value.trim(), user=$("username").value.trim()||"Bot";
  if(!ip){alert("Nhập Server IP trước.");$("serverIp").focus();return}
  save(); updateStatus(true); startedAt=Date.now();
  log(`Connecting ${user} to ${ip}:${$("serverPort").value} (${mode})...`);
  setTimeout(()=>{chat("system",`[SYSTEM] ${user} đã kết nối (demo).`);log("Connection established (UI simulation).")},500);
  timer=setInterval(()=>{
    if(startedAt){
      let s=Math.floor((Date.now()-startedAt)/1000);
      let h=String(Math.floor(s/3600)).padStart(2,"0"),m=String(Math.floor(s%3600/60)).padStart(2,"0"),sec=String(s%60).padStart(2,"0");
      $("uptime").textContent=`${h}:${m}:${sec}`;
    }
  },1000);
};
$("disconnectBtn").onclick=()=>{
  if(farming)toggleFarm();
  updateStatus(false); startedAt=null; $("uptime").textContent="00:00:00";
  clearInterval(timer); log("Disconnected."); chat("system","[SYSTEM] Bot đã ngắt kết nối.");
};
$("farmBtn").onclick=toggleFarm;
function toggleFarm(){
  if(!connected){alert("Hãy CONNECT trước.");return}
  farming=!farming;
  const b=$("farmBtn");
  b.classList.toggle("running",farming);
  b.textContent=farming?"⛔ STOP FARM":"🌾 START FARM";
  log(farming?"Farm/AFK started (demo).":"Farm/AFK stopped.");
  chat("system",farming?"[FARM] Đã bắt đầu vòng lặp AFK/farm (demo).":"[FARM] Đã dừng.");
}
document.querySelectorAll(".action[data-action]").forEach(b=>b.onclick=()=>{
  if(!connected){alert("Hãy CONNECT trước.");return}
  const a=b.dataset.action; log(`Action: ${a}`); chat("system",`[BOT] ${a.toUpperCase()} (demo)`);
});
$("sendBtn").onclick=sendChat;
$("chatInput").onkeydown=e=>{if(e.key==="Enter")sendChat()};
function sendChat(){
  const v=$("chatInput").value.trim();
  if(!v)return;
  if(!connected){alert("Bot chưa CONNECT.");return}
  chat("me",`[YOU] ${v}`); log(`Chat: ${v}`); $("chatInput").value="";
  setTimeout(()=>chat("server","[SERVER] Message queued (demo)."),250);
}
$("clearBtn").onclick=()=>{$("console").textContent=""};
["serverIp","serverPort","username","autoReconnect","antiAfk"].forEach(id=>$(id).addEventListener("change",save));
load();
log("Minecraft Bot UI loaded.");
