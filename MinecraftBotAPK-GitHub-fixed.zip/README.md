# Minecraft Bot APK — fixed GitHub Actions version

Bản này KHÔNG dùng Cordova và KHÔNG dùng androidx.core:core-ktx.
Nó đóng gói HTML vào Android WebView bằng Android Gradle Plugin 8.9.1.

## Upload lên GitHub

Cách dễ nhất:
1. Mở repo Mc-bot.
2. Upload toàn bộ nội dung của ZIP này vào thư mục gốc repo.
3. Nếu GitHub hỏi ghi đè, chọn overwrite/replace cho các file trùng tên.
4. Vào Actions.
5. Chọn "Build Minecraft Bot APK".
6. Bấm "Run workflow".
7. Khi màu xanh, mở run -> Artifacts -> MinecraftBot-APK.
8. Tải MinecraftBot-debug.apk.

## Lưu ý
APK này là giao diện HTML/WebView. Connect/Farm hiện là demo UI, chưa phải Minecraft protocol bot thật.
