# Minecraft Bot Android

Android Studio project for a dual-edition Minecraft bot controller.

## Build

1. Open this folder in Android Studio.
2. Use JDK 17.
3. Let Gradle sync.
4. Build > Generate App Bundle / APK > Generate APK.

The project uses Android Gradle Plugin 9.4.0 and Gradle 9.6.0. AGP 9.4.0 requires JDK 17 and supports API 37.

## Current scope

The UI, foreground service, edition selector, connection controls, log area and farm controls are implemented.

The actual Minecraft protocol engines are deliberately isolated in:
`app/src/main/java/com/skeletonbeo/minecraftbot/BotAdapter.kt`

Before this can act as a real Minecraft client, those two adapters must be connected to:
- Java Edition: GeyserMC MCProtocolLib
- Bedrock Edition: CloudburstMC Protocol

This separation is intentional because Java and Bedrock use different network protocols and authentication/session flows.

## Important

Do not hard-code Microsoft/Xbox account credentials into the APK. For online-mode servers, implement the appropriate official authentication flow and token storage.
