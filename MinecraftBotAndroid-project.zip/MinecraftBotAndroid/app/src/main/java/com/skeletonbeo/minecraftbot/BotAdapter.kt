package com.skeletonbeo.minecraftbot

interface BotAdapter {
    fun connect(host: String, port: Int, username: String)
    fun disconnect()
    fun startFarm()
    fun stopFarm()
}

/*
 * Protocol implementation boundary.
 *
 * Java: integrate GeyserMC MCProtocolLib here.
 * Bedrock: integrate CloudburstMC Protocol here.
 *
 * Keeping protocol code behind this interface lets the Android UI,
 * foreground service, chat stream, reconnect policy and farm state
 * remain identical for both editions.
 */
class JavaBotAdapter : BotAdapter {
    override fun connect(host: String, port: Int, username: String) {
        // TODO: MCProtocolLib session/login implementation.
    }
    override fun disconnect() {}
    override fun startFarm() {}
    override fun stopFarm() {}
}

class BedrockBotAdapter : BotAdapter {
    override fun connect(host: String, port: Int, username: String) {
        // TODO: CloudburstMC RakNet/Bedrock session implementation.
    }
    override fun disconnect() {}
    override fun startFarm() {}
    override fun stopFarm() {}
}
