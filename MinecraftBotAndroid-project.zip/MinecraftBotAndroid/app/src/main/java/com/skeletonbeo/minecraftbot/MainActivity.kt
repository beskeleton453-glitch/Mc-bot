package com.skeletonbeo.minecraftbot

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.skeletonbeo.minecraftbot.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.editionSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Java Edition", "Bedrock Edition")
        )

        b.connectButton.setOnClickListener {
            val intent = Intent(this, BotForegroundService::class.java).apply {
                action = BotForegroundService.CONNECT
                putExtra("edition", b.editionSpinner.selectedItem.toString())
                putExtra("host", b.ipInput.text.toString().trim())
                putExtra("port", b.portInput.text.toString().toIntOrNull() ?: 25565)
                putExtra("username", b.nameInput.text.toString().trim())
            }
            startForegroundService(intent)
            appendLog("[APP] Connect requested")
            b.statusText.text = "● CONNECTING"
        }

        b.disconnectButton.setOnClickListener {
            startService(Intent(this, BotForegroundService::class.java).setAction(BotForegroundService.DISCONNECT))
            b.statusText.text = "● DISCONNECTED"
            appendLog("[APP] Disconnect requested")
        }

        b.farmStartButton.setOnClickListener {
            startService(Intent(this, BotForegroundService::class.java).setAction(BotForegroundService.START_FARM))
            b.farmStatus.text = "Farm: running"
            appendLog("[FARM] Start requested")
        }

        b.farmStopButton.setOnClickListener {
            startService(Intent(this, BotForegroundService::class.java).setAction(BotForegroundService.STOP_FARM))
            b.farmStatus.text = "Farm: stopped"
            appendLog("[FARM] Stop requested")
        }
    }

    private fun appendLog(s: String) {
        b.chatLog.append("$s\n")
    }
}
