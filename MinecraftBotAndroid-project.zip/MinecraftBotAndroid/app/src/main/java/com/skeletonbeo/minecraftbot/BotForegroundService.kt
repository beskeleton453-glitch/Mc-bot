package com.skeletonbeo.minecraftbot

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

class BotForegroundService : Service() {
    companion object {
        const val CONNECT = "CONNECT"
        const val DISCONNECT = "DISCONNECT"
        const val START_FARM = "START_FARM"
        const val STOP_FARM = "STOP_FARM"
        private const val CHANNEL = "minecraft_bot"
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var bot: BotAdapter? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            CONNECT -> {
                startForeground(10, notification("Minecraft Bot running"))
                val edition = intent.getStringExtra("edition") ?: "Java Edition"
                val host = intent.getStringExtra("host") ?: ""
                val port = intent.getIntExtra("port", 25565)
                val username = intent.getStringExtra("username") ?: "Bot"
                bot?.disconnect()
                bot = if (edition.startsWith("Java")) JavaBotAdapter() else BedrockBotAdapter()
                executor.execute { bot?.connect(host, port, username) }
            }
            DISCONNECT -> {
                bot?.disconnect()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            START_FARM -> executor.execute { bot?.startFarm() }
            STOP_FARM -> executor.execute { bot?.stopFarm() }
        }
        return START_STICKY
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Minecraft Bot")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Minecraft Bot", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
