# Protocol integration notes

## Java

MCProtocolLib is maintained by GeyserMC and is a Java library for communicating with Minecraft servers/clients.

Repository:
https://github.com/GeyserMC/MCProtocolLib

The adapter should:
1. Create a client session.
2. Configure host/port and username/profile.
3. Listen for inbound chat packets.
4. Emit status transitions.
5. Send movement/action packets for the farm controller.
6. Reconnect with exponential backoff.

## Bedrock

CloudburstMC Protocol is a Java Bedrock protocol library and currently supports Bedrock Edition protocol versions 1.7.0+.

Repository:
https://github.com/CloudburstMC/Protocol

The adapter should:
1. Create the Bedrock/RakNet connection.
2. Complete login/handshake.
3. Listen for text/chat packets.
4. Emit status transitions.
5. Send movement/action packets for the farm controller.
6. Reconnect with exponential backoff.

## Why the project does not pretend these are interchangeable

A Java server connection and a Bedrock connection are not the same wire protocol. A reliable dual-edition bot therefore needs two protocol adapters, not a simple "version switch".
